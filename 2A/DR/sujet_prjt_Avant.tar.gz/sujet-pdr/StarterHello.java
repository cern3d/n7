
import java.util.Hashtable;

public class StarterHello {

    static Hashtable<String, Object> nameServer = new Hashtable<>();

    public static void main(String[] args) throws Exception {

        int port = 2000;

        Server ns = new Server(port);

        new Thread(ns).start();

        Object lock = new Object();
        nameServer.put("Hello_lock", lock);

        Agent agent = new Hello();
        agent.init("Hello", new Node("localhost", port));
        agent.setNameServer(nameServer);

        synchronized (lock) {
            try {
                agent.main();
                System.out.println("DONE MAIN");
            } catch (MoveException e) {
            }
            lock.wait();
        }
        System.out.println("Agent finished");
    }
}