
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;

public class StarterCompression {

    static Hashtable<String, Object> nameServer = new Hashtable<>();

    public static void main(String[] args) throws Exception {

        int port = 2000;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ServerSocket server = new ServerSocket(port);
                    System.out.println("server ready");
                    while (true) {
                        Socket s = server.accept();
                        ObjectInputStream in = new ObjectInputStream(s.getInputStream());

                        Agent a = (Agent) in.readObject();
                        a.setNameServer(nameServer);
                        System.out.println("received agent");
                        try {
                            a.main();
                        } catch (MoveException e) {
                        }

                        s.close();
                        break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

        Object lock = new Object();
        nameServer.put("Compression_lock", lock);

        Agent agent = new Compression();
        agent.init("Compression", new Node("localhost", port));
        agent.setNameServer(nameServer);

        synchronized (lock) {
            try {
                agent.main();
            } catch (MoveException e) {
            }
            lock.wait();
        }
        System.out.println("Agent finished");
    }
}
