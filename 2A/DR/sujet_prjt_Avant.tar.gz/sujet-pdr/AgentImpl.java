import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.*;
import java.net.Socket;
import java.util.Hashtable;

public class AgentImpl implements Agent {

    private Node place;
    private String name;
    private Node origin;
    private transient Hashtable<String, Object> nameserver;

    public void init(String name, Node origin) {
        this.name = name;
        this.origin = origin;
        this.place = origin;
    }

    public void setNameServer(Hashtable<String, Object> ns) {
        this.nameserver = ns;
    }

    public Hashtable<String, Object> getNameServer() {
        return nameserver;
    }

    public void move(Node target) throws MoveException {
        try {
                    Socket s = new Socket(target.getHostname(), target.getPort());

        OutputStream os = s.getOutputStream();
        
String className = this.getClass().getName(); 
Path classFile = Paths.get(this.getClass().getResource(className + ".class").getPath());
        byte[] classBytes = Files.readAllBytes(classFile);

        // Serialization, Object. 
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(this);
        oos.flush();
        byte[] objectBytes = baos.toByteArray();

        DataOutputStream out = new DataOutputStream(os);

        // Envoie du nom de la classe
        out.writeUTF(className);
        out.writeInt(classBytes.length);
        out.write(classBytes);

        // Envoie de l'objet. 
        out.writeInt(objectBytes.length);
        out.write(objectBytes);
        s.close();

            throw new MoveException("");
        } catch (IOException ex) {
            System.getLogger(AgentImpl.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }

    public void back() throws MoveException {
        move(this.origin);
    }

    public void main() throws MoveException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
