
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Compression extends AgentImpl {

    boolean start = true;
    Node n2 = new Node("localhost", 2002);
    Node place = null;
    String file;

    @Override
    public void main() throws MoveException {
        if (start) {
            start = false;
            place = n2;
            System.out.println("before move to node1: Hello World !!!!");
            move(n2);
        }
        if (place == n2) {
            place = null;
            Path path = Paths.get("C:\\Users\\abdel\\Documents\\Code\\DonneesReparties\\sujet-pdr\\sujet-pdr\\Agent.java");
            try {
                file = Files.readString(path);
                System.out.println("DONE PRINTING");
            } catch (Exception e) {
                e.printStackTrace();
            }
            back();
        }

        System.out.println(file);
        System.out.println("I am back: Hello World !!!!");

        Object o = getNameServer().get(this.getClass().getName() + "_lock");
        synchronized (o) {
            o.notify();
        }
    }
}
