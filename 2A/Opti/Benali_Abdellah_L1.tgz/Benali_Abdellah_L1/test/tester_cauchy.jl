using Test
using LinearAlgebra

"""
Tester la fonction de pas de Cauchy conformément aux 7 cas de figure spécifiés.
"""
function tester_cauchy(cauchy::Function)

    tol_test = 1e-7

    @testset "Pas de Cauchy - Tests Exhaustifs" begin

        # le cas de test 1
        g = [1e-12; 1e-12]
        H = [7.0 0.0; 0.0 2.0]
        Δ = 1.0
        s = cauchy(g, H, Δ, tol_abs=1e-10)
        @test s ≈ [0.0; 0.0] atol = tol_test

        # le cas de test 2
        g = [1.0; 1.0]
        H = [2.0 0.0; 0.0 2.0] # gᵀHg = 4 > 0
        Δ = 2.0
        s = cauchy(g, H, Δ)
        @test s ≈ [-0.5; -0.5] atol = tol_test

        # le cas de test 3
        g = [1.0; 1.0]
        H = [10.0 0.0; 0.0 10.0] # gᵀHg = 20
        Δ = 0.05
        s = cauchy(g, H, Δ)
        @test norm(s) ≈ Δ atol = tol_test
        @test s ≈ -(Δ / norm(g)) * g atol = tol_test

        # le cas de test 4
        g = [1.0; 0.0]
        H = [2.0 0.0; 0.0 -5.0] # gᵀHg = 2 > 0
        Δ = 10.0
        s = cauchy(g, H, Δ)
        @test s ≈ [-0.5; 0.0] atol = tol_test

        # le cas de test 5
        g = [1.0; 0.0]
        H = [2.0 0.0; 0.0 -5.0] # gᵀHg = 2 > 0
        Δ = 0.1
        s = cauchy(g, H, Δ)
        @test s ≈ [-0.1; 0.0] atol = tol_test

        # le cas de test 6
        g = [0.0; 1.0]
        H = [5.0 0.0; 0.0 -2.0] # gᵀHg = -2 < 0
        Δ = 1.0
        s = cauchy(g, H, Δ)
        @test norm(s) ≈ Δ atol = tol_test
        @test s ≈ [0.0; -1.0] atol = tol_test

        # le cas de test 7
        g = [1.0; 1.0]
        H = [1.0 -1.0; -1.0 1.0] # gᵀHg = [1 1]*[0; 0] = 0
        Δ = 5.0
        s = cauchy(g, H, Δ)
        @test norm(s) ≈ Δ atol = tol_test
        @test s ≈ -(Δ / norm(g)) * g atol = tol_test

    end
end