with Ada.Text_IO; use Ada.Text_IO;
with Ada.Command_Line; use Ada.Command_Line;
with Ada.Streams.Stream_IO; use Ada.Streams.Stream_IO;
with Arbre_Huffman; use Arbre_Huffman;
with File_Priorite;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;

procedure Compresser is

    -- Types et constantes
    type T_Octet is mod 256;
    FIN_FICHIER : constant T_Octet := 255; -- Symbole de fin de fichier
    
    -- Tableau pour stocker les fréquences des octets
    type T_Tab_Frequence is array (T_Octet) of Natural;
    
    -- Type pour stocker le code binaire d'un symbole
    type T_Code is record
        Bits : Unbounded_String;
        Longueur : Natural;
    end record;
    
    -- Table des codes de Huffman
    type T_Table_Huffman is array (T_Octet) of T_Code;
    
    -- Configuration du mode d'affichage
    Mode_Bavard : Boolean := True;

    -- Instanciation du module File_Priorite pour les arbres de Huffman
    function Comparer_Arbres(A, B : Noeud_Ptr) return Boolean is
    begin
        return Obtenir_Frequence(A.all) < Obtenir_Frequence(B.all);
    end Comparer_Arbres;
    
    package File_Huffman is new File_Priorite(Element_Type => Noeud_Ptr,
                                            Comparer => Comparer_Arbres);
    use File_Huffman;

    -- Calculer les fréquences des octets dans le fichier
    procedure Calculer_Frequences(Nom_Fichier : in String;
                                Tab_Freq : out T_Tab_Frequence) is
        F : Ada.Streams.Stream_IO.File_Type;
        S : Stream_Access;
        Octet : T_Octet;
    begin
        -- Initialiser le tableau
        for I in Tab_Freq'Range loop
            Tab_Freq(I) := 0;
        end loop;

        -- Ouvrir le fichier et compter les occurrences
        Open(F, In_File, Nom_Fichier);
        S := Stream(F);
        while not End_Of_File(F) loop
            T_Octet'Read(S, Octet);
            Tab_Freq(Octet) := Tab_Freq(Octet) + 1;
        end loop;
        Close(F);
    end Calculer_Frequences;

    -- Construire l'arbre de Huffman
    function Construire_Arbre(Tab_Freq : in T_Tab_Frequence) return Noeud_Ptr is
        F : File_Huffman.File;
        N1, N2, Nouveau : Noeud_Ptr;
    begin
        -- Initialiser la file de priorité
        Initialiser(F);
        
        -- Ajouter les feuilles pour chaque symbole
        for I in Tab_Freq'Range loop
            if Tab_Freq(I) > 0 then
                Ajouter(F, Creer_Noeud(Character'Val(I), Tab_Freq(I)));
            end if;
        end loop;
        
        -- Ajouter le symbole de fin de fichier
        Ajouter(F, Creer_Noeud(Character'Val(FIN_FICHIER), 1));
        
        -- Construire l'arbre
        while not Est_Vide(F) loop
            Retirer(F, N1);
            if Est_Vide(F) then
                return N1;
            end if;
            Retirer(F, N2);
            
            -- Créer un nouveau nœud
            Nouveau := Creer_Noeud(Character'Val(0),
                                 Obtenir_Frequence(N1.all) + Obtenir_Frequence(N2.all),
                                 N1, N2);
            Ajouter(F, Nouveau);
        end loop;
        
        return N1;
    end Construire_Arbre;

    -- Construire la table des codes
    procedure Construire_Table(Arbre : in Noeud_Ptr;
                             Table : out T_Table_Huffman;
                             Code : in Unbounded_String := To_Unbounded_String("");
                             Niveau : in Natural := 0) is
    begin
        if Obtenir_Gauche(Arbre.all)= null and Obtenir_Droit(Arbre.all) = null then
            -- C'est une feuille
            Table(T_Octet'Val(Character'Pos(Obtenir_Symbole(Arbre.all)))) :=
                (Bits => Code, Longueur => Niveau);
        else
            -- Parcourir récursivement
            if Obtenir_Gauche(Arbre.all) /= null then
                Construire_Table(Obtenir_Gauche(Arbre.all), Table,
                               Code & '0', Niveau + 1);
            end if;
            if Obtenir_Droit(Arbre.all) /= null then
                Construire_Table(Obtenir_Droit(Arbre.all), Table,
                               Code & '1', Niveau + 1);
            end if;
        end if;
    end Construire_Table;

    -- Écrire un octet dans le fichier
    procedure Ecrire_Octet(S : in Stream_Access; Octet : in T_Octet) is
    begin
        T_Octet'Write(S, Octet);
    end Ecrire_Octet;

    -- Écrire l'arbre de Huffman dans le fichier
    procedure Ecrire_Structure_Arbre(S : in Stream_Access;
                                   Arbre : in Noeud_Ptr;
                                   Position : in out Natural;
                                   Octet_Courant : in out T_Octet) is
    begin
        if Obtenir_Gauche(Arbre.all) = null and Obtenir_Droit(Arbre.all) = null then
            -- Feuille : écrire 1
            Octet_Courant := T_Octet(2 ** Position) or Octet_Courant;
        end if;
        
        Position := Position + 1;
        if Position = 8 then
            Ecrire_Octet(S, Octet_Courant);
            Position := 0;
            Octet_Courant := 0;
        end if;
        
        if Obtenir_Gauche(Arbre.all) /= null then
            Ecrire_Structure_Arbre(S, Obtenir_Gauche(Arbre.all), Position, Octet_Courant);
        end if;
        if Obtenir_Droit(Arbre.all) /= null then
            Ecrire_Structure_Arbre(S, Obtenir_Droit(Arbre.all), Position, Octet_Courant);
        end if;
    end Ecrire_Structure_Arbre;


    -- Compresser le fichier
    procedure Compresser_Fichier(Nom_Fichier : in String) is
        Tab_Freq : T_Tab_Frequence;
        Arbre : Noeud_Ptr;
        Table : T_Table_Huffman;
        F_In, F_Out : Ada.Streams.Stream_IO.File_Type;
        S_In, S_Out : Stream_Access;
        Octet : T_Octet;
        Octet_Sortie : T_Octet := 0;
        Position_Bit : Natural := 0;
    begin
        -- Calculer les fréquences
        Calculer_Frequences(Nom_Fichier, Tab_Freq);

        -- Construire l'arbre de Huffman
        Arbre := Construire_Arbre(Tab_Freq);
      
        if Mode_Bavard then
            Put_Line("Compression de " & Nom_Fichier);
            Print_Tree(Arbre)
        end if;

        
        -- Construire la table des codes
        Construire_Table(Arbre, Table);

        -- Ouvrir les fichiers
        Open(F_In, In_File, Nom_Fichier);
        Create(F_Out, Out_File, Nom_Fichier & ".hff");
        S_In := Stream(F_In);
        S_Out := Stream(F_Out);

        -- Écrire la structure de l'arbre
        declare
            Position : Natural := 0;
            Octet_Structure : T_Octet := 0;
        begin
            Ecrire_Structure_Arbre(S_Out, Arbre, Position, Octet_Structure);
            if Position > 0 then
                Ecrire_Octet(S_Out, Octet_Structure);
            end if;
        end;

        -- Compresser le fichier
        while not End_Of_File(F_In) loop
            T_Octet'Read(S_In, Octet);
            -- Écrire le code de l'octet
            for I in 1..Length(Table(Octet).Bits) loop
                if Element(Table(Octet).Bits, I) = '1' then
                    Octet_Sortie := Octet_Sortie or T_Octet(2 ** Position_Bit);
                end if;
                Position_Bit := Position_Bit + 1;
                if Position_Bit = 8 then
                    Ecrire_Octet(S_Out, Octet_Sortie);
                    Octet_Sortie := 0;
                    Position_Bit := 0;
                end if;
            end loop;
        end loop;

        -- Écrire le symbole de fin de fichier
        for I in 1..Length(Table(FIN_FICHIER).Bits) loop
            if Element(Table(FIN_FICHIER).Bits, I) = '1' then
                Octet_Sortie := Octet_Sortie or T_Octet(2 ** Position_Bit);
            end if;
            Position_Bit := Position_Bit + 1;
            if Position_Bit = 8 then
                Ecrire_Octet(S_Out, Octet_Sortie);
                Octet_Sortie := 0;
                Position_Bit := 0;
            end if;
        end loop;

        -- Écrire le dernier octet s'il est incomplet
        if Position_Bit > 0 then
            Ecrire_Octet(S_Out, Octet_Sortie);
        end if;

        -- Fermer les fichiers et libérer la mémoire
        Close(F_In);
        Close(F_Out);
        Detruire(Arbre);

        if Mode_Bavard then
            Put_Line("Compression terminée");
        end if;
    end Compresser_Fichier;

    -- Programme principal
begin
    -- Traiter les options de la ligne de commande
    for I in 1..Argument_Count loop
        if Argument(I) = "-s" or Argument(I) = "--silencieux" then
            Mode_Bavard := False;
        elsif Argument(I) = "-b" or Argument(I) = "--bavard" then
            Mode_Bavard := True;
        else
            Compresser_Fichier(Argument(I));
        end if;
    end loop;

end Compresser;