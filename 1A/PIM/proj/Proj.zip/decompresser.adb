with Ada.Text_IO; use Ada.Text_IO;
with Ada.Command_Line; use Ada.Command_Line;
with Ada.Streams.Stream_IO; use Ada.Streams.Stream_IO;
with Arbre_Huffman; use Arbre_Huffman;
with File_Priorite;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;

procedure Decompresser is

    -- Types et constantes
    type T_Octet is mod 256;
    FIN_FICHIER : constant T_Octet := 255;  -- Symbole de fin de fichier

    -- Configuration du mode d'affichage
    Mode_Bavard : Boolean := True;

    -- Lire un octet depuis le fichier
    procedure Lire_Octet(S : in Stream_Access; Octet : out T_Octet) is
    begin
        T_Octet'Read(S, Octet);
    end Lire_Octet;

    -- Lire la liste des symboles du fichier compressé
    procedure Lire_Symboles(S : in Stream_Access; 
                          Position_FDF : out Integer;
                          Symboles : out array of Character) is
        Octet, Dernier_Octet : T_Octet;
        Nb_Symboles : Integer := 0;
    begin
        -- Lire la position du symbole de fin de fichier
        Lire_Octet(S, Octet);
        Position_FDF := Integer(Octet);

        -- Lire les symboles jusqu'à trouver deux octets identiques consécutifs
        Lire_Octet(S, Dernier_Octet);
        Symboles(Nb_Symboles) := Character'Val(Dernier_Octet);
        Nb_Symboles := Nb_Symboles + 1;

        loop
            Lire_Octet(S, Octet);
            exit when Octet = Dernier_Octet;
            Symboles(Nb_Symboles) := Character'Val(Octet);
            Nb_Symboles := Nb_Symboles + 1;
            Dernier_Octet := Octet;
        end loop;
    end Lire_Symboles;

    -- Reconstruire l'arbre à partir de sa structure binaire
    function Reconstruire_Arbre(S : in Stream_Access;
                              Symboles : in array of Character;
                              Index_Symbole : in out Integer) return Noeud_Ptr is
        Octet : T_Octet;
        Position : Integer := 0;
        Bit : Integer;
    begin
        Lire_Octet(S, Octet);
        Bit := Integer(Octet / 128);
        
        if Bit = 1 then
            -- C'est une feuille
            declare
                Nouveau_Noeud : constant Noeud_Ptr := 
                    Creer_Noeud(Symboles(Index_Symbole), 0);
            begin
                Index_Symbole := Index_Symbole + 1;
                return Nouveau_Noeud;
            end;
        else
            -- C'est un nœud interne
            declare
                Gauche, Droit : Noeud_Ptr;
            begin
                Gauche := Reconstruire_Arbre(S, Symboles, Index_Symbole);
                Droit := Reconstruire_Arbre(S, Symboles, Index_Symbole);
                return Creer_Noeud(Character'Val(0), 0, Gauche, Droit);
            end;
        end if;
    end Reconstruire_Arbre;

    -- Décompresser le fichier
    procedure Decompresser_Fichier(Nom_Fichier : in String) is
        F_In, F_Out : Ada.Streams.Stream_IO.File_Type;
        S_In, S_Out : Stream_Access;
        Octet : T_Octet;
        Symboles : array (0..255) of Character;
        Position_FDF : Integer;
        Arbre : Noeud_Ptr;
        Noeud_Courant : Noeud_Ptr;
        Index_Symbole : Integer := 0;
    begin
        if Mode_Bavard then
            Put_Line("Décompression de " & Nom_Fichier);
        end if;

        -- Vérifier l'extension .hff
        if Nom_Fichier'Length <= 4 or else 
           Nom_Fichier(Nom_Fichier'Last-3..Nom_Fichier'Last) /= ".hff" 
        then
            Put_Line("Le fichier doit avoir l'extension .hff");
            return;
        end if;

        -- Ouvrir les fichiers
        Open(F_In, In_File, Nom_Fichier);
        Create(F_Out, Out_File, Nom_Fichier & ".d");
        S_In := Stream(F_In);
        S_Out := Stream(F_Out);

        -- Lire la liste des symboles
        Lire_Symboles(S_In, Position_FDF, Symboles);

        -- Reconstruire l'arbre
        Index_Symbole := 0;
        Arbre := Reconstruire_Arbre(S_In, Symboles, Index_Symbole);

        if Mode_Bavard then
            Put_Line("Arbre reconstruit :");
            Print_Tree(Arbre);
        end if;

        -- Décompression
        Noeud_Courant := Arbre;
        while not End_Of_File(F_In) loop
            Lire_Octet(S_In, Octet);
            
            -- Traiter chaque bit de l'octet
            for I in 0..7 loop
                -- Extraire le bit courant
                if (Octet and T_Octet(2**(7-I))) /= 0 then
                    Noeud_Courant := Obtenir_Droit(Noeud_Courant.all);
                else
                    Noeud_Courant := Obtenir_Gauche(Noeud_Courant.all);
                end if;

                -- Si on arrive sur une feuille
                if Obtenir_Gauche(Noeud_Courant.all) = null and then 
                   Obtenir_Droit(Noeud_Courant.all) = null 
                then
                    -- Vérifier si c'est le symbole de fin de fichier
                    if Character'Pos(Obtenir_Symbole(Noeud_Courant.all)) = 
                       Character'Pos(Symboles(Position_FDF))
                    then
                        goto Fin_Decompression;
                    end if;

                    -- Écrire le symbole dans le fichier de sortie
                    Character'Write(S_Out, Obtenir_Symbole(Noeud_Courant.all));
                    Noeud_Courant := Arbre;
                end if;
            end loop;
        end loop;

        <<Fin_Decompression>>
        -- Fermer les fichiers et libérer la mémoire
        Close(F_In);
        Close(F_Out);
        Detruire(Arbre);

        if Mode_Bavard then
            Put_Line("Décompression terminée");
        end if;

    exception
        when others =>
            Put_Line("Erreur lors de la décompression");
            if Is_Open(F_In) then
                Close(F_In);
            end if;
            if Is_Open(F_Out) then
                Close(F_Out);
            end if;
            if Arbre /= null then
                Detruire(Arbre);
            end if;
            raise;
    end Decompresser_Fichier;

    -- Programme principal
begin
    -- Traiter les options de la ligne de commande
    for I in 1..Argument_Count loop
        if Argument(I) = "-s" or Argument(I) = "--silencieux" then
            Mode_Bavard := False;
        elsif Argument(I) = "-b" or Argument(I) = "--bavard" then
            Mode_Bavard := True;
        else
            Decompresser_Fichier(Argument(I));
        end if;
    end loop;

end Decompresser;