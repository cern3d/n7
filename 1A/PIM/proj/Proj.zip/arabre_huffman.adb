package body Arbre_Huffman is

   -- Procédure pour désallouer un nœud individuel
   procedure Free is new Ada.Unchecked_Deallocation(Noeud, Noeud_Ptr);

   -- Crée un nouveau nœud
   function Creer_Noeud(Symbole : Character; Frequence : Natural; 
                        Gauche, Droit : Noeud_Ptr := null) return Noeud_Ptr is
   begin
      return new Noeud'(Symbole => Symbole, Frequence => Frequence, Gauche => Gauche, Droit => Droit);
   end Creer_Noeud;

   -- Accesseur pour le symbole
   function Obtenir_Symbole(N : Noeud) return Character is
   begin
      return N.Symbole;
   end Obtenir_Symbole;

   -- Accesseur pour la fréquence
   function Obtenir_Frequence(N : Noeud) return Natural is
   begin
      return N.Frequence;
   end Obtenir_Frequence;

   -- Accesseur pour le sous-arbre gauche
   function Obtenir_Gauche(N : Noeud) return Noeud_Ptr is
   begin
      return N.Gauche;
   end Obtenir_Gauche;

   -- Accesseur pour le sous-arbre droit
   function Obtenir_Droit(N : Noeud) return Noeud_Ptr is
   begin
      return N.Droit;
   end Obtenir_Droit;

   procedure Print_Tree (Arbre : in Noeud_Ptr; Prefix : in String := "") is
   begin
      if Arbre /= null then
         -- Afficher la valeur du nœud
         Put_Line ("(" & Integer'Image(Obtenir_Frequence(Arbre.all)) & ")");
         
         -- Traiter sous-arbre gauche
         if Obtenir_Gauche(Arbre.all) /= null then
            Put (Prefix & "| \--0--(");
            Put (Integer'Image(Obtenir_Frequence(Obtenir_Gauche(Arbre.all))));
            if Est_Feuille(Obtenir_Gauche(Arbre.all)) then
               Put_Line (") '" & Obtenir_Symbole(Obtenir_Gauche(Arbre.all)) & "'");
            else
               Put_Line (")");
               Print_Tree (Obtenir_Gauche(Arbre.all), Prefix & "| |");
            end if;
         end if;

         -- Traiter sous-arbre droit
         if Obtenir_Droit(Arbre.all) /= null then
            Put (Prefix & "\--1--(");
            Put (Integer'Image(Obtenir_Frequence(Obtenir_Droit(Arbre.all))));
            if Est_Feuille(Obtenir_Droit(Arbre.all)) then
               Put_Line (") '" & Obtenir_Symbole(Obtenir_Droit(Arbre.all)) & "'");
            else
               Put_Line (")");
               Print_Tree (Obtenir_Droit(Arbre.all), Prefix & "|");
            end if;
         end if;
      end if;
   end Print_Tree;


   function Est_Feuille (N : in T_Noeud) return Boolean is
   begin
      return Obtenir_Gauche(N) = null and then Obtenir_Droit(N) = null;
   end Est_Feuille;

   -- Désalloue l'arbre entier récursivement
   procedure Detruire(Arbre : in out Noeud_Ptr) is
   begin
      if Arbre /= null then
         Detruire(Arbre.Gauche);
         Detruire(Arbre.Droit);
         Free(Arbre); -- Utilisation de `Free` pour libérer le nœud courant
         Arbre := null;  -- Bonne pratique pour éviter des accès invalides
      end if;
   end Detruire;

end Arbre_Huffman;