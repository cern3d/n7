with Ada.Text_IO;         use Ada.Text_IO;
with Arbre_Huffman;       use Arbre_Huffman;

procedure Test_Arbre_Huffman is
   -- Variables
   Arbre : Noeud_Ptr := null;  -- Pointeur vers la racine de l'arbre

   -- Procédure auxiliaire pour afficher l'arbre récursivement
   procedure Afficher_Arbre(Noeud : Noeud_Ptr; Niveau : Integer := 0) is
   begin
      if Noeud /= null then
         -- Afficher les informations du nœud courant
         Put_Line
           (Indent(Niveau * 2) & "Symbole: " & Obtenir_Symbole(Noeud) &
            ", Fréquence: " & Natural'Image(Obtenir_Frequence(Noeud)));

         -- Afficher les sous-arbres gauche et droit
         Afficher_Arbre(Obtenir_Gauche(Noeud), Niveau + 1);
         Afficher_Arbre(Obtenir_Droit(Noeud), Niveau + 1);
      else
         Put_Line(Indent(Niveau * 2) & "<vide>");
      end if;
   end Afficher_Arbre;

begin
   -- Étape 1 : Création d'un arbre simple
   Put_Line("=== TEST : Création d'un arbre ===");
   Arbre := Creer_Noeud(Symbole => 'A', Frequence => 10);
   Arbre.Gauche := Creer_Noeud(Symbole => 'B', Frequence => 5);
   Arbre.Droit := Creer_Noeud(Symbole => 'C', Frequence => 15);

   -- Étape 2 : Accès aux nœuds et affichage de l'arbre
   Put_Line("=== TEST : Accès et affichage de l'arbre ===");
   Afficher_Arbre(Arbre);

   -- Étape 3 : Désallocation de l'arbre
   Put_Line("=== TEST : Désallocation de l'arbre ===");
   Detruire(Arbre);

   -- Vérification que l'arbre a bien été désalloué
   if Arbre = null then
      Put_Line("Arbre désalloué avec succès !");
   else
      Put_Line("Échec de la désallocation de l'arbre !");
   end if;

end Test_Arbre_Huffman;